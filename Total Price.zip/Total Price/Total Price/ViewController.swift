//
//  ViewController.swift
//  Total Price
//
//  Created by Yadavally,Sai Vikram Reddy on 2/24/22.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var product1: UITextField!
    
    @IBOutlet weak var product1Price: UITextField!
    
    @IBOutlet weak var product2: UITextField!
    
    @IBOutlet weak var product2Price: UITextField!
    
    @IBOutlet weak var L1: UILabel!
    @IBOutlet weak var d1: UILabel!
    
    
    @IBOutlet weak var L2: UILabel!
    @IBOutlet weak var d2: UILabel!
    
    @IBOutlet weak var L3: UILabel!
    @IBOutlet weak var d3: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func buttonClicked(_ sender: UIButton) {
        
        var cost1 = Double(product1Price.text!)!
        var cost2 = Double(product2Price.text!)!
        var totalPrice = cost1 + cost2
        var disc = totalPrice - (totalPrice * 25.0/100)
        var tax = disc + (disc * 8.5/100)
        L1.text! = product1.text!
        L2.text! = product2.text!
        L3.text! = "Total price after discount and tax : "
        d1.text! = product1Price.text!
        d2.text! = product2Price.text!
        d3.text! = "$\(tax)"
    }
    
}

